<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="description" content="Zee5 Premium Streamer for FREE">
		<meta name="keywords" content="zee5,zee5streamer,freezee5Premium">
		<meta name="author" content="Prabha">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Zee5 Movie Watches</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
		<link rel="manifest" href="favicon/manifest.json">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
		<meta name="theme-color" content="#ffffff">
	</head>
	<body>
		<main>
			<div class="container">
				<h1><a href="index.php"><img src="img/zee5.png" width="100" height="100"></a></h1>
				<h2>Paste <a href="https://www.zee5.com/" target="_blank">Zee5.com</a> Movie/Series Link</h2>
				<div class="search-box">
					<div class="search-icon"><i class="fa fa-search search-icon"></i></div>
					<form id="myform" method="post" action="zee5.php" class="search-form">
						<input type="text" placeholder="https://www.zee5.com/movies/details/vikram-vedha-2017-watch-it-on-zee5/0-0-movie_1460826290" name="link" id="search" autocomplete="off">
					</form>
					<svg class="search-border" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" viewBox="0 0 671 111" style="enable-background:new 0 0 671 111;"
						xml:space="preserve">
						<path class="border" d="M335.5,108.5h-280c-29.3,0-53-23.7-53-53v0c0-29.3,23.7-53,53-53h280"/>
						<path class="border" d="M335.5,108.5h280c29.3,0,53-23.7,53-53v0c0-29.3-23.7-53-53-53h-280"/>
					</svg>
					<div class="go-icon"><i class="fa fa-arrow-right"></i></div>
					<br>
					<center><div> 👇 Format of Link Should be this 👇</div></center>
					<div>Movie Link:&nbsp;<code>https://www.zee5.com/movies/details/nerkonda-paarvai/0-0-90827 </code></div>
					<br>
					<div>Series Episode Link:&nbsp;<code>https://www.zee5.com/zee5originals/details/pubgoa/0-6-3107/ep-2-two-bullets-one-lie-and-a-mask/0-1-manual_4pn2uk307d80 </code></div>
					<div class="footer">
						Developed by PRABHA
					</div>
				</div>
			</div>
		</main>
		<script type="text/javascript">
			$(document).ready(function(){
		$("#search").focus(function() {
		$(".search-box").addClass("border-searching");
		$(".search-icon").addClass("si-rotate");
		});
		$("#search").blur(function() {
		$(".search-box").removeClass("border-searching");
		$(".search-icon").removeClass("si-rotate");
		});
		$("#search").keyup(function() {
		if($(this).val().length > 0) {
		$(".go-icon").addClass("go-in");
		}
		else {
		$(".go-icon").removeClass("go-in");
		}
		});
		$(".go-icon").click(function(){
		$(".search-form").submit();
		});
		});
		</script>
	</body>
</html>